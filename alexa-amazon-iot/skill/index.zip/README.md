#### Ingredients
## Update Shadow <a id="title"></a>


This skill includes an Intent called ```CityIntent``` with a slot called ```city```, that is of type ```AMAZON.EUROPE_CITY```.

The user will say: ```go to London``` and the skill will update the IOT Device Shadow with the name of the city.

#### Instructions for deploying this sample skill




 * [Part 2 - Create the skill](./PAGE2.md#title)


<hr />

Back to the [Home Page](../../README.md#title)

